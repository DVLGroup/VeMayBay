<?php

define('URL', 'http://'.$_SERVER['HTTP_HOST'].'/');
define('LIBS', 'Libs/');