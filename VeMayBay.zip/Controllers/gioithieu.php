<?php
/**
 * 
 */
class gioithieu extends Controller {
	
	function __construct() {
		parent::__construct();
	}
	function index()
	{
		$this->view->render('gioithieu/index');
	}
}
