<h1 align="center">Quản lý Yêu cầu</h1>

	<div class="container" style="margin-top: 50px">
		<table class="table table-striped table-bordered table-hover" id="table_yeucau" >
		    <thead>
		        <tr class="">
		            <th>ID</th>
		            <th>Họ tên</th>
		            <th>Điểm xuất phát</th>
		            <th>Điểm đến</th>
		            <th>Số lượng</th>
		            <th>Ngày đi</th>
		            <th>Ngày về</th>
		        </tr>
		    </thead>
		    <tbody id="getList_yeuCau_all">
		    	
		    </tbody>
		</table>
	</div>
