<hr class="alert-info" />
<strong class="text-danger">This page does not exists or is under construction please come again later...</strong>