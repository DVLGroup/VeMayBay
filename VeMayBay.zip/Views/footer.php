			<hr class="alert-info" />
		</div>
	</body>
	<footer class="navbar navbar-inverse navbar-fixed-bottom bs-docs-nav">
		<div class="container">
			<p class="collapse navbar-collapse" style="color: white;">
				&copy; 2013 - <?php echo date('Y');?>
				by DVL Grp. All rights reserved. Designed and coded by members of DVL <strong><a href="<?php echo URL; ?>admincp">VIET_NT</a></strong> and <strong><a href="<?php echo URL; ?>admincp">LOI LOI</a></strong>
			</p>

		</div>
	</footer>
</html>